
public class Finish extends GameObject
{
	public Finish(int xC, int yC, int w, int h)
	{
		super(xC*50,yC*50,w*50,h*50);
	}
}
