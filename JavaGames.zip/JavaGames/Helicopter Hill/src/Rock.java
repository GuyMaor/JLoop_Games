
public class Rock extends GameObject
{
	public Rock(int xC, int yC)
	{
		super(xC*50,yC*50,50,50);
	}
}
