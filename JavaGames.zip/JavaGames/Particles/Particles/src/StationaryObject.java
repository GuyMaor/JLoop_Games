public class StationaryObject extends Satellite
{
	public StationaryObject(double xP, double yP, double m)
	{
		super(xP,yP,0,0,m);
	}
	public void moveSatellite(){}
}