
public class Enemy extends BoundingRectangle
{
	public Enemy(int x)
	{
		super(x,-60,60,45);
	}


}
