import java.awt.Color;


public class Shield extends BoundingRectangle
{
	public Shield(int x)
	{
		super(x,-60,60,45);
	}
}
